<?php

return array(
	'dl_csv'      				=> 'التنزيل كملف CSV',
	'eula_text'      			=> 'إتفاقية ترخيص المستخدم النهائي',
    'id'      					=> 'رقم التعريف',
    'require_acceptance'      	=> 'القبول',
    'title'      				=> 'اسم الملحق',


);
