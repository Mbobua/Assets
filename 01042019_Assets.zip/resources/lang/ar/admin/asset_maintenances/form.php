<?php

    return [
        'asset_maintenance_type' => 'نوع الصيانة',
        'title'                  => 'المسمى',
        'start_date'             => 'بدأت',
        'completion_date'        => 'أنجزت',
        'cost'                   => 'التكلفة',
        'is_warranty'            => 'تحسين الضمان',
        'asset_maintenance_time' => 'أيام',
        'notes'                  => 'مُلاحظات',
        'update'                 => 'تعديل',
        'create'                 => 'إنشاء'
    ];
