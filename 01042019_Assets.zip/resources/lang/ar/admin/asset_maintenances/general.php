<?php

    return [
        'asset_maintenances' => 'صيانة الاُصل',
        'edit'               => 'تعديل صيانة الأصل',
        'delete'             => 'حذف صيانة الأصل',
        'view'               => 'عرض تفاصيل صيانة الأصل',
        'repair'             => 'إصلاح',
        'maintenance'        => 'صيانة',
        'upgrade'            => 'الترقية'
    ];
