<?php

    return [
        'title'         => 'صيانة الاُصل',
        'asset_name'    => 'اسم الأصل',
        'is_warranty'   => 'الضمان',
        'dl_csv'        => 'التنزيل كملف CSV'
    ];
