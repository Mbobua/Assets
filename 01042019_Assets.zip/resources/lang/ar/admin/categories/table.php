<?php

return array(
	'eula_text'      			=> 'إتفاقية ترخيص المستخدم النهائي',
    'id'      					=> 'رقم التعريف',
    'parent'   					=> 'التصنيف الأب',
    'require_acceptance'      	=> 'القبول',
    'title'      				=> 'اسم تصنيف الأصول',

);
