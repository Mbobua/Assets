<?php
return array(
    'companies' => 'الشركات',
    'create'    => 'إنشاء شركة',
    'title'     => 'شركة',
    'update'    => 'تحديث الشركة',
    'name'      => 'إسم الشركة',
    'id'        => 'رقم التعريف',
);
