<?php

return array(
    'title'      				=> 'اسم المكون',
);
