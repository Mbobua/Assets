<?php

return array(
    'title'      				=> 'إسم المادة الإستهلاكية',
);
