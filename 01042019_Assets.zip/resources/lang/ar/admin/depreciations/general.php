<?php

return array(
    'about_asset_depreciations'  			=> 'حول استهلاك الأصول',
    'about_depreciations'  					=> 'يمكنك إعداد استهلاك الأصول لخفض قيمة الأصول على اساس القسط الثابت للاستهلاك.',
    'asset_depreciations'  					=> 'استهلاك الأصول',
    'create'  					            => 'إنشاء الاستهلاك',
    'depreciation_name'  					=> 'اسم الاستهلاك',
    'number_of_months'  					=> 'عدد الأشهر',
    'update'  					            => 'تحديث الاستهلاك',

);
