<?php

return array(

    'id'      => 'رقم التعريف',
    'months'   => 'أشهر',
    'term'   => 'المدة',
    'title'      => 'الإسم ',

);
