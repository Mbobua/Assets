<?php

return array(

    'id'         => 'رقم التعريف',
    'name'       => 'الإسم',
    'users'      => 'عدد المستخدمين',

);
