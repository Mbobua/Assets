<?php

return array(
    'about_groups_title'            => 'حول المجموعات',
    'about_groups'                  => 'تستخدم المجموعات لتعميم صلاحيات المستخدم.',
    'group_management' 	 	=> 'إدارة المجموعة',
    'create' 	 	 	    => 'إنشاء مجموعة جديدة',
    'update' 	 		        => 'تعديل المجموعة',
    'group_name' 	 		=> 'اسم المجموعة',
    'group_admin' 	 		=> 'مدير المجموعة',
    'allow' 	 			=> 'سماح',
    'deny' 	 				=> 'منع',

);
