<?php

return array(

    'asset_tag'   	=> 'ترميز الأصل',
    'asset_model'       => 'الموديل',
    'book_value'  	=> 'القيمة',
    'change' 		=> 'ادخال \\ اخراج',
    'checkout_date' => 'تاريخ الاخراج',
    'checkoutto' 	=> 'الاخراج',
    'diff' 			=> 'الفرق',
    'dl_csv' 		=> 'التنزيل كملف CSV',
    'eol' 			=> 'نهاية العمر',
    'id'      		=> 'رقم التعريف',
    'location' 		=> 'الموقع',
    'purchase_cost'	=> 'التكلفة',
    'purchase_date'	=> 'تم الشراء',
    'serial'   		=> 'التسلسل',
    'status'   		=> 'الحالة',
    'title'      	=> 'أصل ',
    'image'		=> 'صورة الجهاز',
    'days_without_acceptance' => 'أيام بدون قبول'

);
