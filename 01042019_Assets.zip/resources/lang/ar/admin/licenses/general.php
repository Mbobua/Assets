<?php

return array(
    'about_licenses_title'            => 'حول التراخيص',
    'about_licenses'                  => 'تستخدم التراخيص لتتبع البرمجيات. كل لديه عدد محدد من المقاعد التي يمكن اخراجها للأفراد',
    'checkin'  					=> 'ادخال مقعد الترخيص',
    'checkout_history'  		=> 'أرشيف الاخراج',
    'checkout'  				=> 'اخراج مقعد ترخيص',
    'edit'  					=> 'تعديل الترخيص',
    'filetype_info'				=> 'انواع صيغ الملفات المسوح بها هي png, gif, jpg, jpeg, doc, docx, pdf, txt, zip, و rar.',
    'clone'  					=> 'استنساخ الترخيص',
    'history_for'  				=> 'الأرشيف ل ',
    'in_out'  					=> 'ادخال \\ اخراج',
    'info'  					=> 'معلومات الترخيص',
    'license_seats'  			=> 'مقاعد الترخيص',
    'seat'  					=> 'مقعد',
    'seats'  					=> 'مقاعد',
    'software_licenses'  		=> 'تراخيص البرامج',
    'user'  					=> 'مستخدم',
    'view'  					=> 'عرض الترخيص',
);
