<?php

return array(

    'assigned_to'   	=> 'عينت الى',
    'checkout'   		=> 'داخل\\خارج',
    'id'      			=> 'رقم التعريف',
    'license_email'   	=> 'البريد الإلكتروني للترخيص',
    'license_name'   	=> 'مرخص الى',
    'purchase_date'   	=> 'تاريخ الشراء',
    'purchased'   		=> 'تم الشراء',
    'seats'   			=> 'مقاعد',
    'hardware'   		=> 'أجهزة',
    'serial'   			=> 'التسلسل',
    'title'      		=> 'الترخيص',

);
