<?php

return array(
    'about'      	=> 'حول تسميات الحالة',
    'archived'      	=> 'مؤرشف',
    'create'      	=> 'إنشاء تسمية الحالة',
    'color'      	=> 'لون الرسم البياني',
    'default_label' => 'الوسم الافتراضي',
    'default_label_help' => 'This is used to ensure your most commonly used status labels appear at the top of the select box when creating/editing assets.',
    'deployable'      	=> 'قابل للتوزيع',
    'info'      	=> 'يتم استخدام تسميات الحالة لوصف الحالات المحتملة للأصول التابعة لك. قد تكون قيد الصيانة أو ضمن المفقودة أو المسروقة، وما إلى ذلك. يمكنك إنشاء تسميات حالة جديدة للأصول القابلة للتوزيع وقيد الانتظار والمؤرشفة.',
    'name'      	=> 'اسم الحالة',
    'pending'      	=> 'قيد الانتظار',
    'status_type'   => 'نوع الحالة',
    'show_in_nav'   => 'أظهِر في الشريط الجانبي',
    'title'      	=> 'تسميات الحالة',
    'undeployable'  => 'غير قابل للتوزيع',
    'update'      	=> 'تحديث تسمية الحالة',
);
