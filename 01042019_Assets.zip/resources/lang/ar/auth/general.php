<?php

return [
    'send_password_link'	        => 'إرسال رسالة إعادة تعيين كلمة المرور',
    'email_reset_password'			=> 'البريد الإلكتروني إعادة تعيين كلمة المرور',
    'reset_password'			    => 'إعادة تعيين كلمة المرور',
    'login'                         => 'الدخول',
    'login_prompt'                  => 'الرجاء تسجيل الدخول',
    'forgot_password'               => 'نسيت كلمة المرور',
    'remember_me'                   => 'تذكرني',
    ];

