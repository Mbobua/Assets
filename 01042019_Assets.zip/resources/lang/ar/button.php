<?php

return array(
    'actions' 	                => 'الإجراءات',
    'add'    	                => 'إضافة جديد',
    'cancel'                    => 'إلغاء',
    'checkin_and_delete'  	    => 'فحص وحذف المستخدم',
    'delete'  	                => 'حذف',
    'edit'    	                => 'تعديل',
    'restore' 	                => 'إستعادة',
    'request'                   => 'طلب',
    'submit'  	                => 'إرسال',
    'upload'                    => 'رفع',
	'select_file'				=> 'حدد ملف ...',
    'select_files'				=> 'إختيار ملف...',
);
