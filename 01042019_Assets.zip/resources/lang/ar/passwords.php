<?php

return [
    'sent'	        => 'تم إرسال رابط كلمة المرور الخاصة بك!',
    'user'			=> 'No matching active user found with that email.',
];

