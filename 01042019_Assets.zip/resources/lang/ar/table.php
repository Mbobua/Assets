<?php

return array(

    'actions'	 	=> 'الإجراءات',
    'action' 		=> 'الإجراء',
    'by'      		=> 'بواسطة',
    'item' 			=> 'عنصر',

);
