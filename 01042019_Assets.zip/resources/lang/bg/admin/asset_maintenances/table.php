<?php

    return [
        'title'         => 'Поддръжка на активи',
        'asset_name'    => 'Име на Актив',
        'is_warranty'   => 'Гаранция',
        'dl_csv'        => 'Сваляне на CSV'
    ];
