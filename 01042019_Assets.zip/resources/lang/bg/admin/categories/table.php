<?php

return array(
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'parent'   					=> 'Горна категория',
    'require_acceptance'      	=> 'Утвърждаване',
    'title'      				=> 'Категория на актива',

);
