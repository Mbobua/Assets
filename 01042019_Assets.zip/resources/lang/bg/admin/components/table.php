<?php

return array(
    'title'      				=> 'Име на компонент.',
);
