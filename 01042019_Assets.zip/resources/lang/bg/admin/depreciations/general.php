<?php

return array(
    'about_asset_depreciations'  			=> 'Относно амортизацията на активи',
    'about_depreciations'  					=> 'Тук можете да конфигурирате линейна амортизация на активи във времето.',
    'asset_depreciations'  					=> 'Амортизация на активи',
    'create'  					            => 'Създаване на амортизация',
    'depreciation_name'  					=> 'Амортизация',
    'number_of_months'  					=> 'Брой месеци',
    'update'  					            => 'Обновяване на амортизация',

);
