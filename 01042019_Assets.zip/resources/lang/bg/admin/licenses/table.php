<?php

return array(

    'assigned_to'   	=> 'Предоставен на',
    'checkout'   		=> 'Предоставяне',
    'id'      			=> 'ID',
    'license_email'   	=> 'Лицензиран на Email',
    'license_name'   	=> 'Лицензиран на',
    'purchase_date'   	=> 'Дата на закупуване',
    'purchased'   		=> 'Закупен',
    'seats'   			=> 'Потребителски лицензи',
    'hardware'   		=> 'Хардуер',
    'serial'   			=> 'Сериен номер',
    'title'      		=> 'Лиценз',

);
