<?php

return [
    'send_password_link'	        => 'Изпрати връзка за повторно задаване на паролата',
    'email_reset_password'			=> 'Имейл за нулиране на паролата',
    'reset_password'			    => 'Нулиране на паролата',
    'login'                         => 'Логин',
    'login_prompt'                  => 'Моля влезте в системата',
    'forgot_password'               => 'Забравих си паролата',
    'remember_me'                   => 'Запомни ме',
    ];

