<?php

return array(
    'actions' 	                => 'Действия',
    'add'    	                => 'Добави нов',
    'cancel'                    => 'Отказ',
    'checkin_and_delete'  	    => 'Вписване и изтриване на потребител',
    'delete'  	                => 'Изтриване',
    'edit'    	                => 'Редакция',
    'restore' 	                => 'Възстановяване',
    'request'                   => 'Заявка',
    'submit'  	                => 'Потвърди',
    'upload'                    => 'Качване',
	'select_file'				=> 'Изберете файл...',
    'select_files'				=> 'Изберете файлове...',
);
