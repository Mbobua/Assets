<?php

return [
    'sent'	        => 'Линк към вашата парола бе изпратен!',
    'user'			=> 'No matching active user found with that email.',
];

