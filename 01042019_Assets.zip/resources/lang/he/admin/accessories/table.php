<?php

return array(
	'dl_csv'      				=> 'הורדה כ-CSV',
	'eula_text'      			=> 'רשיון שימוש',
    'id'      					=> 'מזהה',
    'require_acceptance'      	=> 'קבלה',
    'title'      				=> 'שם אבזר',


);
