<?php

    return [
        'asset_maintenance_type' => 'סוג תחזוקה',
        'title'                  => 'כותרת',
        'start_date'             => 'התחיל',
        'completion_date'        => 'הושלם',
        'cost'                   => 'מחיר',
        'is_warranty'            => 'שיפור באחריות',
        'asset_maintenance_time' => 'ימים',
        'notes'                  => 'הערות',
        'update'                 => 'עדכון',
        'create'                 => 'לִיצוֹר'
    ];
