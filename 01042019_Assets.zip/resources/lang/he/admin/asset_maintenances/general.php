<?php

    return [
        'asset_maintenances' => 'אחזקת נכסים',
        'edit'               => 'עריכת תחזוקת נכס',
        'delete'             => 'מחיקת תחזוקת נכס',
        'view'               => 'הצג פרטי אחזקת נכס',
        'repair'             => 'תיקון',
        'maintenance'        => 'תחזוקה',
        'upgrade'            => 'שדרוג'
    ];
