<?php

    return [
        'title'         => 'תחזוקת נכס',
        'asset_name'    => 'שם הנכס',
        'is_warranty'   => 'אחריות',
        'dl_csv'        => 'להוריד CSV'
    ];
