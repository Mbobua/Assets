<?php
return array(
    'companies' => 'חברות',
    'create'    => 'צור חברה',
    'title'     => 'חֶברָה',
    'update'    => 'עדכון החברה',
    'name'      => 'שם החברה',
    'id'        => 'תְעוּדַת זֶהוּת',
);
