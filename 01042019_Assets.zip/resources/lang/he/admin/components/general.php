<?php

return array(
    'about_components_title' 			=> 'על רכיבים',
    'about_components_text'  			=> 'רכיבים הם פריטים שהם חלק מנכס, לדוגמה HDD, RAM וכדומה.',
    'component_name'                  => 'שם רכיב',
    'checkin'                             => 'רכיב Checkin',
    'checkout'                             => 'רכיב Checkout',
    'cost'				=> 'עלות הרכישה',
    'create'                             => 'צור רכיב',
    'edit'                             => 'עריכת רכיב',
    'date'					=> 'תאריך רכישה',
    'order'					=> 'מספר הזמנה',
    'remaining' 			             => 'נוֹתָר',
    'total' 			                 => 'סה"כ',
    'update'                            => 'עדכון רכיב',
);
