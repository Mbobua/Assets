<?php

return array(
    'title'      				=> 'שם רכיב',
);
