<?php

return array(

    'id'                        => 'תְעוּדַת זֶהוּת',
    'name'                      => 'שם מחלקה',
    'manager'                   => 'מנהל',
    'location'                  => 'מקום',
    'create'                    => 'יצירת המחלקה',
    'update'                    => 'עדכון המחלקה',
    );
