<?php

return array(

    'asset'             => 'נכס',
    'checkin'           => 'קבלה',
    'create'            => 'צור רישיון',
    'expiration'        => 'תאריך תפוגה',
    'license_key'       => 'מפתח מוצר',
    'maintained'        => 'נשמר',
    'name'              => 'שם התוכנה',
    'no_depreciation'   => 'לא פוחת',
    'purchase_order'    => 'מספר הזמנה',
    'reassignable'      => 'ניתן להקצות מחדש',
    'remaining_seats'   => 'מקומות ישיבה שנותרו',
    'seats'             => 'מקומות ישיבה',
    'termination_date'  => 'תאריך סיום',
    'to_email'          => 'מורשה לדוא"ל',
    'to_name'           => 'מורשה לשם',
    'update'            => 'עדכון רשיון',
    'checkout_help'     => 'עליך לבדוק רשיון לנכס חומרה או לאדם. תוכל לבחור את שניהם, אך הבעלים של הנכס חייב להתאים לאדם שאליו אתה בודק את הנכס.'
);
