<?php

return array(
    'about_licenses_title'            => 'על רישיונות',
    'about_licenses'                  => 'רשיונות משמשים למעקב אחר תוכנה. יש להם מספר מסוים של מושבים כי ניתן לבדוק את הפרטים',
    'checkin'  					=> 'רישיון רישיון',
    'checkout_history'  		=> 'היסטוריית Checkout',
    'checkout'  				=> 'רישיון',
    'edit'  					=> 'רישיון עריכה',
    'filetype_info'				=> 'סוגי קבצים מותרים הם png, gif, jpg, jpeg, doc, docx, pdf, txt, zip, ו rar.',
    'clone'  					=> 'רישיון שיבוט',
    'history_for'  				=> 'היסטוריה עבור',
    'in_out'  					=> 'בפנים בחוץ',
    'info'  					=> 'פרטי רישיון',
    'license_seats'  			=> 'מושבי רשיון',
    'seat'  					=> 'מושב',
    'seats'  					=> 'מקומות ישיבה',
    'software_licenses'  		=> 'רשיונות תוכנה',
    'user'  					=> 'מִשׁתַמֵשׁ',
    'view'  					=> 'הצג רישיון',
);
