<?php

return array(

    'assigned_to'   	=> 'מוקצה ל-',
    'checkout'   		=> 'ניפוק/החזרה',
    'id'      			=> 'מזהה',
    'license_email'   	=> 'דוא"ל רשיון',
    'license_name'   	=> 'רשום על שם',
    'purchase_date'   	=> 'תאריך הרכישה',
    'purchased'   		=> 'נרכש',
    'seats'   			=> 'מספר',
    'hardware'   		=> 'ציוד',
    'serial'   			=> 'מספר סידורי',
    'title'      		=> 'רישיון',

);
