<?php

return array(
    'error'   => 'עליך לבחור לפחות אפשרות אחת.'
);
