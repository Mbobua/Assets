<?php

return array(
    'about_suppliers_title' => 'על הספקים',
    'about_suppliers_text'  => 'הספקים משמשים כדי לעקוב אחר המקור של פריטים',
    'address'               => 'כתובת הספק',
    'assets'                => 'נכסים',
    'city'                  => 'עִיר',
    'contact'               => 'שם איש קשר',
    'country'               => 'מדינה',
    'create'                => 'צור ספק',
    'email'                 => 'אֶלֶקטרוֹנִי',
    'fax'                   => 'פַקס',
    'id'                    => 'תְעוּדַת זֶהוּת',
    'licenses'              => 'רישיונות',
    'name'                  => 'שם ספק',
    'notes'                 => 'הערות',
    'phone'                 => 'טלפון',
    'state'                 => 'מדינה',
    'suppliers'             => 'ספקים',
    'update'                => 'עדכון הספק',
    'url'                   => 'כתובת אתר',
    'view'                  => 'הצג את הספק',
    'view_assets_for'       => 'הצג נכסים עבור',
    'zip'                   => 'מיקוד',

);
