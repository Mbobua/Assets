<?php

return array(
    'actions' 	                => 'פעולות',
    'add'    	                => 'הוסף חדש',
    'cancel'                    => 'לְבַטֵל',
    'checkin_and_delete'  	    => 'מחק & מחק משתמש',
    'delete'  	                => 'לִמְחוֹק',
    'edit'    	                => 'לַעֲרוֹך',
    'restore' 	                => 'לשחזר',
    'request'                   => 'בַּקָשָׁה',
    'submit'  	                => 'שלח',
    'upload'                    => 'העלה',
	'select_file'				=> 'בחר קובץ...',
    'select_files'				=> 'Select Files...',
);
