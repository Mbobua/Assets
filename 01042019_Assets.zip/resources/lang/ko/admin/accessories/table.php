<?php

return array(
	'dl_csv'      				=> 'CSV로 내려받기',
	'eula_text'      			=> '사용권 계약서',
    'id'      					=> '아이디',
    'require_acceptance'      	=> '승인',
    'title'      				=> '부속품 명',


);
