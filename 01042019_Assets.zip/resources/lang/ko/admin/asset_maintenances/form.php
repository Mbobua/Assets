<?php

    return [
        'asset_maintenance_type' => '자산 관리 유형',
        'title'                  => '제목',
        'start_date'             => '시작일',
        'completion_date'        => '완료일',
        'cost'                   => '비용',
        'is_warranty'            => '보증 개선',
        'asset_maintenance_time' => '자산 관리 기간(일 단위)',
        'notes'                  => '주석',
        'update'                 => '자산 관리 갱신',
        'create'                 => '자산 관리 생성'
    ];
