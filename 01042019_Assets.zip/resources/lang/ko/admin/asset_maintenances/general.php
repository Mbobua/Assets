<?php

    return [
        'asset_maintenances' => '자산 관리',
        'edit'               => '자산 관리 수정',
        'delete'             => '자산 관리 삭제',
        'view'               => '자산 관리 상세 보기',
        'repair'             => '수리',
        'maintenance'        => '관리',
        'upgrade'            => '개선'
    ];
