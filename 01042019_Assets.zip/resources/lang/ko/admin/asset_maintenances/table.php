<?php

    return [
        'title'         => '자산 관리',
        'asset_name'    => '자산명',
        'is_warranty'   => '보증',
        'dl_csv'        => 'CSV로 내려받기'
    ];
