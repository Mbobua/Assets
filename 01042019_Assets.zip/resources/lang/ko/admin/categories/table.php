<?php

return array(
	'eula_text'      			=> '사용권 계약서',
    'id'      					=> '아이디',
    'parent'   					=> '상위',
    'require_acceptance'      	=> '승인',
    'title'      				=> '자산 분류 명',

);
