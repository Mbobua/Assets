<?php
return [
    'about_companies_title'            => '회사 란',
    'about_companies_text'                  => '회사들은 단순한 식별 항목으로 사용될 수 있고, 전사 지원이 관리 설정에서 활성화 된다면 자산, 사용자, 기타 등의 표시 제한에 사용 될 수 있습니다.',
    'select_company' => '회사 선택',
];
