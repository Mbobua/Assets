<?php
return array(
    'companies' => '회사들',
    'create'    => '회사 생성',
    'title'     => '회사',
    'update'    => '회사 갱신',
    'name'      => '회사명',
    'id'        => '아이디',
);
