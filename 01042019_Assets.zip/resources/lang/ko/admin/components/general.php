<?php

return array(
    'about_components_title' 			=> '부품이란',
    'about_components_text'  			=> '부품들은 HDD, RAM 같은, 한개의 자산의 일부분입니다.',
    'component_name'                  => '부품명',
    'checkin'                             => '반입 부품',
    'checkout'                             => '반출 부품',
    'cost'				=> '구매 원가',
    'create'                             => '부품 생성',
    'edit'                             => '부품 수정',
    'date'					=> '구매 일자',
    'order'					=> '주문 번호',
    'remaining' 			             => '잔여수량',
    'total' 			                 => '총계',
    'update'                            => '부품 갱신',
);
