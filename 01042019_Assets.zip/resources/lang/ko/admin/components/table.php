<?php

return array(
    'title'      				=> '부품명',
);
