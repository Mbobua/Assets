<?php

return array(
    'about_consumables_title' 			=> '소모품이란',
    'about_consumables_text'  			=> '소모품은 시간이 지남에 따라 소진되어 구매해야 하는 것들 입니다. 예로, 프린터 잉크나 복사 용지가 있습니다.',
    'checkout'                          => '사용자에게 소모품 반출',
    'consumable_name'                   => '소모품 명',
    'create'                            => '소모품 생성',
    'item_no'                           => '항목 번호',
    'remaining' 			            => '잔여수량',
    'total' 			                => '총계',
    'update'                            => '소모품 갱신',
);
