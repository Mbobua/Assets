<?php

return array(
    'title'      				=> '소모품 명',
);
