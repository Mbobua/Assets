<?php

return array(

    'id'                        => 'ID',
    'name'                      => '부서 명',
    'manager'                   => '관리자',
    'location'                  => '위치',
    'create'                    => '부서 생성',
    'update'                    => '부서 갱신',
    );
