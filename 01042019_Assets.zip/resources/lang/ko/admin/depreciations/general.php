<?php

return array(
    'about_asset_depreciations'  			=> '자산 감가 상각이란',
    'about_depreciations'  					=> '가치가 하락하는 자산들을 직선법에 의한 감가상각 설정을 할 수 있습니다.',
    'asset_depreciations'  					=> '자산 감가 상각',
    'create'  					            => '감가 상각 생성',
    'depreciation_name'  					=> '감가 상각 명',
    'number_of_months'  					=> '개월 수',
    'update'  					            => '감가 상각 갱신',

);
