<?php

return array(

    'id'      => '아이디',
    'months'   => '개월',
    'term'   => '기간',
    'title'      => '이름 ',

);
