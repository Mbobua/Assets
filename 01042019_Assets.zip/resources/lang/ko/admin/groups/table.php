<?php

return array(

    'id'         => '아이디',
    'name'       => '이름',
    'users'      => '사용자 # 명',

);
