<?php

return array(
    'about_groups_title'            => '그룹이란',
    'about_groups'                  => '그룹은 일반적인 당신의 권한에 사용된다.',
    'group_management' 	 	=> '그룹 관리',
    'create' 	 	 	    => '새 그룹 생성',
    'update' 	 		        => '그룹 수정',
    'group_name' 	 		=> '그룹 명',
    'group_admin' 	 		=> '그룹 관리자',
    'allow' 	 			=> '허용',
    'deny' 	 				=> '거부',

);
