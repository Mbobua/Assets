<?php

return array(

    'asset_tag'   	=> '자산 태그',
    'asset_model'       => '모델',
    'book_value'  	=> '가치',
    'change' 		=> '입/출',
    'checkout_date' => '반출 일자',
    'checkoutto' 	=> '반출 확인',
    'diff' 			=> '차액',
    'dl_csv' 		=> 'CSV로 내려받기',
    'eol' 			=> '폐기일',
    'id'      		=> '아이디',
    'location' 		=> '위치',
    'purchase_cost'	=> '원가',
    'purchase_date'	=> '구매',
    'serial'   		=> '일련번호',
    'status'   		=> '상태',
    'title'      	=> '자산 ',
    'image'		=> '장비 사진',
    'days_without_acceptance' => '미 승인 기간'

);
