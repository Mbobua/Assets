<?php

return array(
    'about_licenses_title'            => '라이선스 란',
    'about_licenses'                  => '라이선스는 소프트웨어를 추적하는데 사용됩니다. 개인에게 반출 할 수 있는 수량이 정의되어 있습니다',
    'checkin'  					=> '라이선스 Seat 확인',
    'checkout_history'  		=> '반출 이력',
    'checkout'  				=> '반출 라이선스 Seat',
    'edit'  					=> '라이선스 편집',
    'filetype_info'				=> '허용되는 형식들은 png, gif, jpeg, doc, docx, pdf, txt, zip, rar 입니다.',
    'clone'  					=> '라이선스 복제',
    'history_for'  				=> '이력 ',
    'in_out'  					=> '입/출',
    'info'  					=> '라이선스 정보',
    'license_seats'  			=> '라이선스 Seats',
    'seat'  					=> 'Seat',
    'seats'  					=> 'Seats',
    'software_licenses'  		=> '소프트웨어 라이선스',
    'user'  					=> '사용자',
    'view'  					=> '라이선스 보기',
);
