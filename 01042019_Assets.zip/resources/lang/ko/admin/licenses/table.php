<?php

return array(

    'assigned_to'   	=> '사용자',
    'checkout'   		=> '입/출',
    'id'      			=> '아이디',
    'license_email'   	=> '라이선스 메일주소',
    'license_name'   	=> '인증 대상',
    'purchase_date'   	=> '구매 일자',
    'purchased'   		=> '구매',
    'seats'   			=> 'Seats',
    'hardware'   		=> '하드웨어',
    'serial'   			=> '일련번호',
    'title'      		=> '라이선스',

);
