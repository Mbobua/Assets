<?php

return array(
    'about_manufacturers_title'    => '제조업체 란',
    'about_manufacturers_text'  => '생산자는 당신의 자산들을 생산한 회사들입니다. 여기에 자산 상세 페이지에 나타날, 그들에 대한 중요한 지원 연락처 정보를 저장 할 수 있습니다.',
    'asset_manufacturers'	=> '자산 제조업체',
    'create'				=> '제조업체 생성',
    'id'   					=> '아이디',
    'name'      			=> '이름',
    'support_email'   		=> '지원 이메일',
    'support_phone'   		=> '지원 전화',
    'support_url'   		=> '지원 URL',
    'update'				=> '제조업체 갱신',
    'url'   				=> 'URL',

);
