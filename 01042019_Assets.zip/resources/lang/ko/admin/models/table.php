<?php

return array(

    'create'				=> '자산 모델 생성',
    'created_at' 			=> '생성 위치',
    'eol'	 				=> '폐기일',
    'modelnumber'   		=> '모델 번호.',
    'name'      			=> '자산 모델 명',
    'numassets' 			=> '자산',
    'title'					=> '자산 모델',
    'update'				=> '자산 모델 갱신',
    'view'					=> '자산 모델 보기',
    'update'				=> '자산 모델 갱신',
    'clone'				=> '모델 복제',
    'edit'				=> '모델 편집',
);
