<?php

return array(
    'info'   => '자산 보고서의 옵션을 선택해 주세요.'
);
