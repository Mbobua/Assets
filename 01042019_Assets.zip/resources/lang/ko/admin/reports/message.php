<?php

return array(
    'error'   => '적어도 옵션 하나는 선택해 주세요.'
);
