<?php

return [
    'send_password_link'	        => '비밀번호 재설정 링크 보내기',
    'email_reset_password'			=> '이메일 비밀번호 재설정',
    'reset_password'			    => '비밀번호 재설정',
    'login'                         => '로그인',
    'login_prompt'                  => '로그인해주십시오',
    'forgot_password'               => '비밀번호 분실했습니다',
    'remember_me'                   => '자동 로그인',
    ];

