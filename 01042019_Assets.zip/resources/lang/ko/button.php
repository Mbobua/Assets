<?php

return array(
    'actions' 	                => '기능',
    'add'    	                => '추가',
    'cancel'                    => '취소',
    'checkin_and_delete'  	    => '반입 & 삭제 사용자',
    'delete'  	                => '삭제',
    'edit'    	                => '편집',
    'restore' 	                => '복원',
    'request'                   => '요청',
    'submit'  	                => '제출',
    'upload'                    => '올리기',
	'select_file'				=> '파일 선택...',
    'select_files'				=> '파일 선택...',
);
