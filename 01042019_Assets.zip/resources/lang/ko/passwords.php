<?php

return [
    'sent'	        => '귀하의 비밀번호 링크가 전송되었습니다!',
    'user'			=> 'No matching active user found with that email.',
];

