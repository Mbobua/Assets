<?php

return array(

    'actions'	 	=> '기능',
    'action' 		=> '작업',
    'by'      		=> '요청자',
    'item' 			=> '항목',

);
