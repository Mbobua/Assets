<?php
return array (
  'app_version' => 'v4.6.5',
  'full_app_version' => 'v4.6.5 - build 3897-gff824ec4d',
  'build_version' => '3897',
  'prerelease_version' => '',
  'hash_version' => 'gff824ec4d',
  'full_hash' => 'v4.6.5-15-gff824ec4d',
  'branch' => 'master',
);
